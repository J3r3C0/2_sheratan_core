# Sheratan Core v2 Package
__version__ = "2.0.0"
